#include "ofApp.h"

void ofApp::setup(){
    ofPushMatrix();
    ofBackground(0);
    ofSetLineWidth(3);
    mesh = mesh.plane(20, 20);
    cam_vert = 0;
    cam_horz = 500;
    cam_dist = 500;
    cam.setPosition(cam_horz, cam_vert, cam_dist);
    cam.setTarget(mesh.getCentroid());
    cam.setAutoDistance(true);
    
    state = 1;
    turn_count = 0;
    mode_grid = 1;
    mode_cam = 1;
}

void ofApp::update(){
    draw_mesh();
}

void ofApp::draw(){
    ofDrawBitmapString("f: toggle fullscreen\ng: toggle grid\nl: lock/unlock cam\nr: reset\ns: save image", 100, 100);
    
    cam.begin();
    mesh.drawWireframe();
    if(mode_grid)
        ofDrawGrid(40,200);
    
    cam.end();
    
}

void ofApp::keyPressed(int key){
    switch (key) {
            break;
        case 'f':
            ofToggleFullscreen();
            break;
        case 'g':
            if(mode_grid)
                mode_grid = 0;
            else
                mode_grid = 1;
            break;
        case 'l':
            if(mode_cam)
                mode_cam = 0;
            else
                mode_cam = 1;
            break;
        case 'r':
            reset();
            break;
        case 's':
            string filename;
            filename = "screen10.png";
            ofSaveScreen(filename);
            break;
    }
    
}

void ofApp::draw_mesh(){
    new_mesh = mesh.getMeshForIndices(mesh.getNumIndices()-4, mesh.getNumIndices());
    
    
    switch (state){
        {
        case 1:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 10, -10));
            if(cmpf(new_mesh.getCentroid().y,100)){
                state = 2;
            }
            break;
        case 2:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -90), ofPoint(0, 100, -100));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 3;
            }
            break;
        case 3:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 0));
            if(cmpf(new_mesh.getCentroid().y,-200)){
                state = 4;
            }
            break;
        }//1
        {
        case 4:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -200, -200));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 5;
            }
            break;
        case 5:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -45), ofPoint(0, -200, -300));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 6;
            }
            break;
        case 6:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 10));
            if(cmpf(new_mesh.getCentroid().y,-400)){
                state = 7;
                
            }
            break;
        case 7:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -45), ofPoint(0, -400, -100));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 8;
            }
            break;
        case 8:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, -10));
            if(cmpf(new_mesh.getCentroid().z,-300)){
                state = 9;
            }
            break;
        }//2
        {
        case 9:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, -10));
            if(cmpf(new_mesh.getCentroid().z,-500)){
                state = 10;
            }
            break;
        case 10:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 45), ofPoint(0, -400, -500));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 11;
            }
            break;
        case 11:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 10));
            if(cmpf(new_mesh.getCentroid().z,-400)){
                state = 12;
            }
            break;
        case 12:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -600, -400));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 13;
            }
            break;
        case 13:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -45), ofPoint(0, -700, -400));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 14;
            }
            break;
        case 14:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, 10));
            if(cmpf(new_mesh.getCentroid().z,-300)){
                state = 15;
            }
            break;
        }//3
        {
        case 15:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, 10));
            if(cmpf(new_mesh.getCentroid().z,-100)){
                state = 16;
            }
            break;
        case 16:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 45), ofPoint(0, -700, -100));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 17;
            }
            break;
        case 17:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 10, -10));
            if(cmpf(new_mesh.getCentroid().z,-250)){
                state = 18;
            }
            break;
        case 18:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 45), ofPoint(0, -550, -250));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 19;
            }
            break;
        case 19:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 0));
            if(cmpf(new_mesh.getCentroid().y,-850)){
                state = 20;
            }
            break;
        }//4
        {
        case 20:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 90), ofPoint(0, -850, -250));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 21;
            }
            break;
        case 21:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, -10));
            if(cmpf(new_mesh.getCentroid().z,-350)){
                state = 22;
            }
            break;
        case 22:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, 10));
            if(cmpf(new_mesh.getCentroid().z,-250)){
                state = 23;
            }
            break;
        case 23:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 90), ofPoint(0, -850, -250));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 24;
            }
            break;
        case 24:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 0));
            if(cmpf(new_mesh.getCentroid().y,-950)){
                state = 25;
            }
            break;
        case 25:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 90), ofPoint(0, -950, -250));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 26;
            }
            break;
        case 26:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -1050, -250));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 27;
            }
            break;
            
        }//5
        {
        case 27:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 5), ofPoint(0, -1300, -250));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 28;
            }
            break;
        case 28:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 10), ofPoint(0, -1375, -200));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 29;
            }
            break;
        }//6
        {
        case 29:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, -10));
            if(cmpf(new_mesh.getCentroid().z,-450)){
                state = 30;
            }
            break;
        case 30:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 45), ofPoint(0, -1450, -450));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 31;
            }
            break;
        case 31:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 5));
            if(cmpf(new_mesh.getCentroid().z,-250)){
                state = 32;
            }
            break;
        case 32:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -45), ofPoint(0, -1850, -250));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 33;
            }
            break;
        }//7
        {
        case 33:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 5), ofPoint(0, -1950, -250));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 34;
            }
            break;
        case 34:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -2150, -250));
            turn_count++;
            if(turn_count == 72){
                turn_count = 0;
                state = 35;
            }
            break;
        case 35:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 5), ofPoint(0, -1950, -250));
            turn_count++;
            if(turn_count == 72){
                turn_count = 0;
                state = 36;
            }
            break;
        case 36:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -2150, -250));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 37;
            }
            break;
        }//8
        {
        case 37:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 10), ofPoint(0, -2350, -300));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 38;
            }
            break;
        case 38:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -5), ofPoint(0, -2450, -250));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                state = 39;
            }
            break;
        }//9
        {
        case 39:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 10, -10));
            if(cmpf(new_mesh.getCentroid().y,-2550)){
                state = 40;
            }
            break;
        case 40:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, -90), ofPoint(0, -2550, -350));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 41;
            }
            break;
        case 41:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, -10, 0));
            if(cmpf(new_mesh.getCentroid().y,-2850)){
                state = 42;
            }
            break;
        case 42:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 90), ofPoint(0, -2850, -350));
            turn_count++;
            if(turn_count == 1){
                turn_count = 0;
                state = 43;
            }
            break;
        case 43:
            new_mesh = tran_mesh(new_mesh, ofPoint(0, 0, -10));
            if(cmpf(new_mesh.getCentroid().z,-550)){
                state = 44;
            }
            break;
            
        case 44:
            new_mesh = rot_mesh(new_mesh , ofPoint(0, 0, 10), ofPoint(0, -2700, -550));
            turn_count++;
            if(turn_count == 36){
                turn_count = 0;
                reset();
            }
            break;
        }//10
            
    }
    if(mode_cam)
        cam.setPosition(cam_horz, new_mesh.getCentroid().y + cam_vert, new_mesh.getCentroid().z + cam_dist);
    cam.setTarget(new_mesh.getCentroid());
    
    mesh.append(new_mesh);
}

ofMesh ofApp::tran_mesh(ofMesh t_mesh, ofPoint t){
    for(int i=0; i<t_mesh.getNumVertices(); i++){
        t_mesh.getVertices()[i].x += t.x;
        t_mesh.getVertices()[i].y += t.y;
        t_mesh.getVertices()[i].z += t.z;
    }
    return t_mesh;
}

ofMesh ofApp::rot_mesh(ofMesh r_mesh, ofPoint degree, ofPoint c){
    
    ofVec3f temp;
    
    for(int i=0; i<r_mesh.getNumVertices(); i++){
        temp =r_mesh.getVertices()[i];
        
        temp.x -= c.x;
        temp.y -= c.y;
        temp.z -= c.z;
        
        temp.rotate(degree.z, degree.y, degree.x);  //R(yaw,pitch,row)
        
        temp.x += c.x;
        temp.y += c.y;
        temp.z += c.z;
        
        r_mesh.getVertices()[i] = temp;
    }
    return r_mesh;
}

void ofApp::reset(){
    mesh = tran_mesh(mesh, ofPoint(ofRandom(-5000, 5000), ofRandom(-5000, 5000), ofRandom(-5000, 5000)));
    new_mesh = new_mesh.plane(20, 20);
    mesh.append(new_mesh);
    state = 1;
}


