#pragma once

#include "ofMain.h"

class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    void keyPressed(int key);

    
    void draw_mesh();
    ofMesh tran_mesh(ofMesh t_mesh, ofPoint t);
    ofMesh rot_mesh(ofMesh r_mesh, ofPoint degree, ofPoint c);
    void reset();
    
    bool cmpf(float A, float B, float epsilon = 0.005f){
        return (fabs(A - B) < epsilon);
    }

    ofMesh mesh, new_mesh;
    ofEasyCam cam;
    int state, turn_count, cam_vert, cam_horz, cam_dist, mode_grid, mode_cam;
};
